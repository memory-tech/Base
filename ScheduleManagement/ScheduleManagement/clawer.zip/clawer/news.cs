﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ScheduleManagement.clawer
{
    class news//对取到的信息进行赋值生产一个实例
    {
        public string name;
        public string Day;
        public string Time;
        public string actors;
        public string scores;
        public string type;
        public string Link;
        public string Player1;
        public string Player2;
        public string Turn;
        public string weekday;
        public string state;
        public string place;
        public string money;
        public string danwei;
    }
}
